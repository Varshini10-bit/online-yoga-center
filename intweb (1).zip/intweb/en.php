<?php

$password="akash pk";

echo password_hash($password,PASSWORD_DEFAULT);

?>